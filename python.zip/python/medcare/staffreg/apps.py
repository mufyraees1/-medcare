from django.apps import AppConfig


class StaffregConfig(AppConfig):
    name = 'staffreg'
