from django.shortcuts import render
from django.http import HttpResponse
from staffreg.models import Staff
from django.db.models import Max
from login.models import Login

# from availdays.models import Drdays
# Create your views here.
def staff(request):
    if request.method == "POST":
        obj = Staff()
        ob = Login()
        sid = Staff.objects.all().aggregate(Max('drid'))

        sidd = list(sid.values())[0]

        siddv = ''
        # for character assigied auto inctement id generttion
        # if not (sidd is None):
        #   siddv="m"+str(sidd+1)
        # else:
        #     siddv="m1"
        #     sidd=0
        obj.drid = sidd + 1

        ob.id = sidd + 1
        #obj.logid = ob.id

        ob.username = request.POST.get("email")
        ob.pwd = request.POST.get("pass")
        ob.type = request.POST.get("staff")
        ob.save()

        obj.name = request.POST.get("name")
        obj.address = request.POST.get("ad")
        obj.dob = request.POST.get("dob")
        obj.phone = request.POST.get("pno")
        obj.email = request.POST.get("email")
        obj.deptid = request.POST.get("dpt")
        obj.qualification = request.POST.get("qualification")
        obj.gender = request.POST.get("gender")
        obj.logid = ob.logid
        obj.save()
        ob.save()

       # o.save()
    return render(request,'staffreg/doctr2.htm')
def viewstaff(request):
    objlist=Staff.objects.all()
    context={
        'objval':objlist,
    }
    return render(request,'staffreg/view.html',context)
def staffedit(request,idd):
    objlist = Staff.objects.get(drid=idd)
    context = {
        'objval': objlist,
    }

    return render(request,'staffreg/staffedit.html',context)
def staffremove(request,idd):
    pass