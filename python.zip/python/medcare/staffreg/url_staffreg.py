from django.conf.urls import url,include
from staffreg import views

urlpatterns = [


    url('^$', views.staff,name='staff'),
    url('^view/', views.viewstaff, name='viewstaff'),
    url('^staffedit/(?P<idd>\w+)',views.staffedit,name='staffedit'),
    url('^staffremove/(?P<idd>\w+)',views.staffremove,name='staffremove'),

]
