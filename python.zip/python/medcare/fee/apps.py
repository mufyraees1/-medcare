from django.apps import AppConfig


class FeeConfig(AppConfig):
    name = 'fee'
