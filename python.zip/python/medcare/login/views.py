from django.shortcuts import render,redirect
from django.http import HttpResponse
from login.models import Login
# Create your views here.
def login(request):
        if request.method == "POST":
            uname = request.POST.get('name')
            pssw = request.POST.get('psw')
            obj = Login.objects.filter(username=uname, pwd=pssw)
            tp = ""
            for ob in obj:
                tp = ob.type
                if tp == "admin":
                    return render(request, 'staffreg/doctr2.htm')
                elif tp == "doctor":

                    return render(request, 'login/login.html')

                elif tp == "nurse":

                    return render(request, 'login/login.html')

                elif tp == "reception":

                    return render(request, 'patientreg/patnt.html')

                elif tp == "pharmacy":

                    return render(request, 'login/login.html')

                else:
                    return render(request, 'login/login.html')

        return render(request, 'login/login.html')
def home(request):
    return render(request,'login/home.html')

