from django.apps import AppConfig


class TestresltConfig(AppConfig):
    name = 'testreslt'
