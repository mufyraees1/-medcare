from django.apps import AppConfig


class AppoinmentConfig(AppConfig):
    name = 'appoinment'
