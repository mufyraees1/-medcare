from django.conf.urls import url,include
from appoinment import views

urlpatterns = [


    url('ppointment/', views.approval,name='approval'),
    url('$^',views.appointment,name='appointment')
]
