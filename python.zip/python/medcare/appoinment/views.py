from django.shortcuts import render
from django.http import HttpResponse
from django.db import connection
# Create your views here.
def approval(request):
    return render(request,'appoinment/appoinmtapprvl.html')
def appointment(request):
    objlist = connection.cursor()
    objlist.execute("select s.name,a.date,p.fname,p.phone from staff s inner join appoinment a on s.drid = a.drid inner join patient p on p.pid = a.pid")

    context = {
        'objval': objlist.fetchall(),
    }

    return render(request,'appoinment/appointment.html',context)