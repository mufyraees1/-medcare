from django.conf.urls import url,include
from notify import views
urlpatterns = [


    url('^$/', views.notif,name='notif'),

]
