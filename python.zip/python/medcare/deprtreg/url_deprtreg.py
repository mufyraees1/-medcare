from django.conf.urls import url,include
from deprtreg import views

urlpatterns = [

    url('^$', views.dept, name='dept'),
    url('^lab/', views.lab, name='lab'),

]
