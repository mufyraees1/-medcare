
from django.shortcuts import render
from django.http import HttpResponse
from deprtreg.models import Department
# Create your views here.
def dept(request):
    if request.method == "POST":
        obj = Department()
        # obj.dptid = request.POST.get("name")
        obj.name = request.POST.get("deptname")

        obj.save()
    return render(request,'deprtreg/deprtReg.html')

def lab(request):
    return  render(request,'deprtreg/labreg.html')