from django.apps import AppConfig


class DeprtregConfig(AppConfig):
    name = 'deprtreg'
