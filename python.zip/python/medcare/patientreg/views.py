from django.shortcuts import render
from django.http import HttpResponse
from patientreg.models import Patient
from  login.models import Login
from appoinment.models import Appoinment
from django.db.models import Max
# Create your views here.
def patientreg(request):
    if request.method == "POST":
        o = Patient()
        ob = Login()
        ap = Appoinment()
        sid = Patient.objects.all().aggregate(Max('pid'))

        sidd = list(sid.values())[0]

        siddv = ''
        # for character assigied auto inctement id generttion
        # if not (sidd is None):
        #   siddv="m"+str(sidd+1)
        # else:
        #     siddv="m1"
        #     sidd=0
        o.pid = sidd + 1

        ob.id = sidd + 1

        ob.username = request.POST.get("name")
        ob.pwd = request.POST.get("pass")
        ob.type = 'patient'
        ob.save()
        o.fname = request.POST.get("name")
        o.mname = request.POST.get("mname")
        o.lname = request.POST.get("lname")
        o.gender = request.POST.get("gender")
        o.phone = request.POST.get("pno")
        o.house = request.POST.get("house")
        o.city = request.POST.get("city")
        o.pin = request.POST.get("pin")
        o.nationality = request.POST.get("nation")
        o.logid = ob.logid
        ap.date = request.POST.get("rdate")
        ap.drid = request.POST.get("dr")
        ap.pid = o.pid

        o.save()
        ob.save()
        ap.save()
    return render(request,'patientreg/patnt.html')