from django.conf.urls import url,include
from patientreg import views

urlpatterns = [


    url('^$', views.patientreg,name='patientreg'),

]
