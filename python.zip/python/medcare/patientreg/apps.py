from django.apps import AppConfig


class PatientregConfig(AppConfig):
    name = 'patientreg'
