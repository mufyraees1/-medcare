from django.conf.urls import url
from availdays import views

urlpatterns = [

    url('^$', views.days, name='days'),
]