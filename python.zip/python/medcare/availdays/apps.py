from django.apps import AppConfig


class AvaildaysConfig(AppConfig):
    name = 'availdays'
