
from django.shortcuts import render
from fee.models import Cfee
from availdays.models import Drdays
from django.http import HttpResponse
# Create your views here.
def days(request):
  if request.method == "POST":
   of = Cfee()
   oa = Drdays()
   #of.drid = "1"
   #oa.drid = 1
   of.fee = request.POST.get("fee")
   oa.day = request.POST.get("days")
   oa.tfrom = request.POST.get("mon")
   oa.tto = request.POST.get("mon1")
   oa.save()
   of.save()
  return render(request,'availdays/fee.html')
