from django.apps import AppConfig


class TreatmentConfig(AppConfig):
    name = 'treatment'
